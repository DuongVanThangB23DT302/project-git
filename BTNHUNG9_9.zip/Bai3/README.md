# Bài tập 03 - STM32F103 - PA0..PA7 Input, PA8..PA15 Output

## 1. Yêu cầu

- PA0..PA7: Input.
- PA8..PA15: Output.
- Đọc 8 bit tại PA0..PA7.
- Đảo từng bit: 0 thành 1, 1 thành 0.
- Ghi 8 bit kết quả ra PA8..PA15 để điều khiển 8 LED.
- Thử nghiệm bằng 8 nút nhấn và 8 LED.

Project này viết bare-metal bằng thanh ghi, biên dịch trực tiếp trên Linux bằng GNU Arm Embedded Toolchain.

## 2. Đấu nối

### Nút nhấn

Chương trình bật pull-up nội cho PA0..PA7.

- Một chân nút SW0 -> PA0, chân còn lại -> GND.
- SW1 -> PA1 -> GND.
- SW2 -> PA2 -> GND.
- SW3 -> PA3 -> GND.
- SW4 -> PA4 -> GND.
- SW5 -> PA5 -> GND.
- SW6 -> PA6 -> GND.
- SW7 -> PA7 -> GND.

Không nhấn: chân vào = 1.
Nhấn: chân vào = 0.
Sau khi đảo bit, nhấn nút sẽ làm LED tương ứng sáng.

### LED

Mỗi LED mắc nối tiếp điện trở 220-330 ohm:

- PA8  -> R -> Anode LED0; Cathode -> GND.
- PA9  -> R -> Anode LED1; Cathode -> GND.
- PA10 -> R -> Anode LED2; Cathode -> GND.
- PA11 -> R -> Anode LED3; Cathode -> GND.
- PA12 -> R -> Anode LED4; Cathode -> GND.
- PA13 -> R -> Anode LED5; Cathode -> GND.
- PA14 -> R -> Anode LED6; Cathode -> GND.
- PA15 -> R -> Anode LED7; Cathode -> GND.

## 3. Lưu ý rất quan trọng về PA13-PA15

PA13 và PA14 mặc định là SWDIO/SWCLK, PA15 mặc định thuộc giao tiếp JTAG.
Để đúng yêu cầu bài tập và dùng PA8..PA15 đều làm Output, chương trình tắt JTAG/SWD bằng AFIO_MAPR.

Sau khi firmware chạy, ST-Link có thể mất kết nối SWD. Nếu cần nạp lại, có thể:

1. Giữ nút RESET trên Blue Pill.
2. Bắt đầu lệnh nạp/kết nối ST-Link.
3. Nhả RESET khi công cụ bắt đầu kết nối.

Hoặc dùng chế độ "connect under reset" của công cụ nạp.

## 4. Cài công cụ trên Ubuntu/Debian

```bash
sudo apt update
sudo apt install gcc-arm-none-eabi binutils-arm-none-eabi make stlink-tools
```

Kiểm tra:

```bash
arm-none-eabi-gcc --version
make --version
st-flash --version
```

## 5. Biên dịch trên Terminal Linux

Đi vào thư mục project:

```bash
cd STM32F103_Bai03_Linux
```

Biên dịch:

```bash
make clean
make
```

Sau khi biên dịch thành công, thư mục `build/` có:

- `bai03.elf`
- `bai03.hex`
- `bai03.bin`
- `bai03.map`
- `main.o`
- `startup_stm32f103.o`

## 6. Nạp bằng ST-Link

Kết nối:

- ST-Link SWDIO -> PA13
- ST-Link SWCLK -> PA14
- ST-Link GND -> GND
- ST-Link 3.3V -> 3.3V (nếu dùng ST-Link cấp nguồn)

Nạp:

```bash
make flash
```

Hoặc:

```bash
st-flash write build/bai03.bin 0x08000000
```

## 7. Nguyên lý chương trình

Lệnh chính:

```c
uint32_t input_data = GPIOA_IDR & 0x00FFU;
uint32_t inverted_data = (~input_data) & 0x00FFU;
GPIOA_ODR = (GPIOA_ODR & 0x00FFU) | (inverted_data << 8);
```

Ví dụ PA0..PA7 đọc được:

```text
11111110
```

Sau khi đảo:

```text
00000001
```

Dịch trái 8 bit rồi đưa ra PA8..PA15 nên PA8 = 1 và LED0 sáng.
