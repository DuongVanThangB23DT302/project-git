#include <stdint.h>

/* STM32F103 peripheral registers */
#define RCC_APB2ENR   (*(volatile uint32_t *)0x40021018U)

#define AFIO_MAPR     (*(volatile uint32_t *)0x40010004U)

#define GPIOA_CRL     (*(volatile uint32_t *)0x40010800U)
#define GPIOA_CRH     (*(volatile uint32_t *)0x40010804U)
#define GPIOA_IDR     (*(volatile uint32_t *)0x40010808U)
#define GPIOA_ODR     (*(volatile uint32_t *)0x4001080CU)

#define RCC_AFIOEN    (1U << 0)
#define RCC_IOPAEN    (1U << 2)

#define AFIO_SWJ_CFG_MASK        (7U << 24)
#define AFIO_SWJ_CFG_DISABLE_ALL (4U << 24)

static void gpio_init(void)
{
    /* Enable AFIO and GPIOA clocks. */
    RCC_APB2ENR |= RCC_AFIOEN | RCC_IOPAEN;

    /*
     * PA13/PA14 are SWD pins and PA15 is a JTAG pin by default.
     * The exercise requires PA8..PA15 all to be GPIO outputs, so
     * disable both JTAG-DP and SW-DP and reclaim PA13..PA15 as GPIO.
     */
    AFIO_MAPR = (AFIO_MAPR & ~AFIO_SWJ_CFG_MASK) | AFIO_SWJ_CFG_DISABLE_ALL;

    /*
     * PA0..PA7: input with pull-up/pull-down.
     * For STM32F1: MODE=00, CNF=10 -> nibble 0b1000 = 0x8.
     */
    GPIOA_CRL = 0x88888888U;

    /* Select internal pull-up for PA0..PA7 by setting corresponding ODR bits. */
    GPIOA_ODR |= 0x00FFU;

    /*
     * PA8..PA15: general-purpose push-pull output, max speed 2 MHz.
     * MODE=10, CNF=00 -> nibble 0b0010 = 0x2.
     */
    GPIOA_CRH = 0x22222222U;

    /* Initially turn off all LEDs on PA8..PA15. */
    GPIOA_ODR &= 0x00FFU;
}

int main(void)
{
    gpio_init();

    while (1)
    {
        /* Read PA0..PA7. */
        uint32_t input_data = GPIOA_IDR & 0x00FFU;

        /* Invert 8 bits: 0 -> 1 and 1 -> 0. */
        uint32_t inverted_data = (~input_data) & 0x00FFU;

        /*
         * Write inverted bit 0..7 to PA8..PA15.
         * Preserve PA0..PA7 ODR bits because they select the input pull-ups.
         */
        GPIOA_ODR = (GPIOA_ODR & 0x00FFU) | (inverted_data << 8);
    }
}
