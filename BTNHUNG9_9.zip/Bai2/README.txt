STM32F103C8T6 - 8 LED RUNNING LIGHT PA0..PA7
================================================

Yeu cau bai tap:
- Cau hinh 8 chan PA0..PA7 o che do Output.
- Chi 01 LED sang tai mot thoi diem.
- LED chay tu trai sang phai: PA0 -> PA1 -> ... -> PA7.
- Den PA7 thi dao chieu: PA6 -> PA5 -> ... -> PA0.
- Lap lai lien tuc.

Noi phan cung de phu hop code:
PA0 -> R 220..330 ohm -> LED1 -> GND
PA1 -> R 220..330 ohm -> LED2 -> GND
PA2 -> R 220..330 ohm -> LED3 -> GND
PA3 -> R 220..330 ohm -> LED4 -> GND
PA4 -> R 220..330 ohm -> LED5 -> GND
PA5 -> R 220..330 ohm -> LED6 -> GND
PA6 -> R 220..330 ohm -> LED7 -> GND
PA7 -> R 220..330 ohm -> LED8 -> GND

Dat LED1..LED8 theo thu tu trai -> phai de quan sat dung huong.

Toc do hien tai:
#define LED_DELAY_MS 200U

Sua thanh 100U -> chay nhanh hon.
Sua thanh 500U -> chay cham hon.
Sua thanh 1000U -> moi buoc 1 giay.

Build tren Linux:
./build_linux.sh

Build tren Windows CMD:
build_windows_cmd.bat

Nap file BIN bang ST-Link:
st-flash write led_runner.bin 0x08000000

Cac file dau ra:
main.o
startup_stm32f103.o
led_runner.elf
led_runner.bin
led_runner.hex
led_runner.map
led_runner.lst
