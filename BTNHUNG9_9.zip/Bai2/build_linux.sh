#!/usr/bin/env bash
set -e
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -Os -ffreestanding -fno-builtin -c main.c -o main.o
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -c startup_stm32f103.s -o startup_stm32f103.o
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -nostdlib main.o startup_stm32f103.o -T STM32F103C8Tx_FLASH.ld -Wl,-Map=led_runner.map -o led_runner.elf
arm-none-eabi-objcopy -O binary led_runner.elf led_runner.bin
arm-none-eabi-objcopy -O ihex led_runner.elf led_runner.hex
arm-none-eabi-objdump -d -S led_runner.elf > led_runner.lst
arm-none-eabi-size led_runner.elf
