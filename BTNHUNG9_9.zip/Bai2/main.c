#include <stdint.h>

/*
 * STM32F103C8T6 - 8 LED running light on PA0..PA7
 * LED connection assumed active-high:
 *   PAx -> resistor 220..330 ohm -> LED -> GND
 *
 * Default MCU clock after reset: HSI = 8 MHz.
 */

#define RCC_BASE        0x40021000UL
#define GPIOA_BASE      0x40010800UL
#define SYSTICK_BASE    0xE000E010UL

#define RCC_APB2ENR     (*(volatile uint32_t *)(RCC_BASE + 0x18UL))
#define GPIOA_CRL       (*(volatile uint32_t *)(GPIOA_BASE + 0x00UL))
#define GPIOA_BSRR      (*(volatile uint32_t *)(GPIOA_BASE + 0x10UL))
#define GPIOA_BRR       (*(volatile uint32_t *)(GPIOA_BASE + 0x14UL))

#define SYST_CSR        (*(volatile uint32_t *)(SYSTICK_BASE + 0x00UL))
#define SYST_RVR        (*(volatile uint32_t *)(SYSTICK_BASE + 0x04UL))
#define SYST_CVR        (*(volatile uint32_t *)(SYSTICK_BASE + 0x08UL))

#define LED_MASK        0x00FFU
#define LED_DELAY_MS    200U    /* Change this value to change running speed */

static void systick_init_1ms(void)
{
    /* HSI 8 MHz: 8,000 clock cycles = 1 ms */
    SYST_RVR = 8000U - 1U;
    SYST_CVR = 0U;

    /* CLKSOURCE = CPU clock, TICKINT = 0, ENABLE = 1 */
    SYST_CSR = (1U << 2) | (1U << 0);
}

static void delay_ms(uint32_t ms)
{
    while (ms--)
    {
        while ((SYST_CSR & (1U << 16)) == 0U)
        {
            /* Wait for COUNTFLAG */
        }
    }
}

static void led_show(uint8_t index)
{
    /* Turn off PA0..PA7, then turn on exactly one LED. */
    GPIOA_BRR = LED_MASK;
    GPIOA_BSRR = (1U << index);
}

int main(void)
{
    int i;

    /* Enable GPIOA clock: RCC_APB2ENR.IOPAEN = 1 (bit 2). */
    RCC_APB2ENR |= (1U << 2);

    /*
     * Configure PA0..PA7 as General Purpose Output Push-Pull, 2 MHz.
     * For each pin in GPIOA_CRL:
     *   CNF = 00
     *   MODE = 10
     * Four-bit value = 0b0010 = 0x2
     * Therefore GPIOA_CRL = 0x22222222.
     */
    GPIOA_CRL = 0x22222222UL;

    /* All LEDs off initially. */
    GPIOA_BRR = LED_MASK;

    systick_init_1ms();

    while (1)
    {
        /* Left -> right: PA0, PA1, ..., PA7 */
        for (i = 0; i <= 7; ++i)
        {
            led_show((uint8_t)i);
            delay_ms(LED_DELAY_MS);
        }

        /* Right -> left: PA6, PA5, ..., PA1.
         * PA7 and PA0 are not repeated at the turning points.
         */
        for (i = 6; i >= 1; --i)
        {
            led_show((uint8_t)i);
            delay_ms(LED_DELAY_MS);
        }
    }
}
