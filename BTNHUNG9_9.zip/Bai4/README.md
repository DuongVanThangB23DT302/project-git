# STM32F103 - Bài tập nút nhấn đảo trạng thái LED

## Yêu cầu

- Cấu hình 1 chân Input để đọc nút nhấn.
- Cấu hình 1 chân Output để điều khiển LED.
- Khi người dùng **nhấn rồi nhả** nút, LED đảo trạng thái.
- Khi không có tương tác, LED giữ nguyên trạng thái vừa điều khiển.
- Hoạt động tương tự nút nguồn của thiết bị điện tử.

## Cấu hình được sử dụng

- Vi điều khiển: STM32F103C8T6 / Blue Pill.
- Nút nhấn: PA0, Input Pull-up.
- LED: PC13, Output Push-Pull 2 MHz.
- LED onboard Blue Pill tại PC13 là active-low.
- Chống dội nút: 20 ms khi nhấn và 20 ms khi nhả.
- SysTick sử dụng clock mặc định HSI 8 MHz để tạo khoảng thời gian 1 ms.

## Nguyên lý

Trạng thái ban đầu LED tắt. PA0 được kéo lên mức 1 bằng điện trở pull-up nội. Khi nhấn nút, PA0 xuống mức 0. Chương trình xác nhận trạng thái nhấn trong 20 ms, sau đó chờ cho đến khi người dùng nhả nút. Sau khi xác nhận nhả ổn định trong 20 ms, biến `led_state` được đảo và trạng thái mới được xuất ra PC13.

Do trạng thái LED được lưu trong biến `led_state`, sau khi người dùng nhả nút và không tương tác thêm, LED vẫn giữ nguyên trạng thái. Lần nhấn-rồi-nhả tiếp theo sẽ đảo lại trạng thái LED.

## Build trên Linux

Cài toolchain:

```bash
sudo apt update
sudo apt install gcc-arm-none-eabi binutils-arm-none-eabi make stlink-tools
```

Build:

```bash
cd STM32F103_Bai04_Linux
make clean
make
```

Các file tạo ra nằm trong `build/`:

- `bai04.elf`
- `bai04.hex`
- `bai04.bin`
- `bai04.map`
- `main.o`
- `startup_stm32f103.o`

## Nạp chương trình

```bash
make flash
```

hoặc:

```bash
st-flash write build/bai04.bin 0x08000000
```

## Kiểm tra thực tế

1. Cấp nguồn cho Blue Pill.
2. LED PC13 ban đầu tắt.
3. Nhấn giữ nút PA0: LED chưa đổi trạng thái.
4. Nhả nút: LED sáng.
5. Nhấn rồi nhả lần tiếp theo: LED tắt.
6. Tiếp tục thao tác, LED sẽ luân phiên ON/OFF sau mỗi lần nhấn-rồi-nhả.
