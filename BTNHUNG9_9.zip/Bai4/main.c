#include <stdint.h>
#include <stdbool.h>

/* ===================== STM32F103 register definitions ===================== */
#define RCC_APB2ENR   (*(volatile uint32_t *)0x40021018U)

#define GPIOA_CRL     (*(volatile uint32_t *)0x40010800U)
#define GPIOA_IDR     (*(volatile uint32_t *)0x40010808U)
#define GPIOA_ODR     (*(volatile uint32_t *)0x4001080CU)

#define GPIOC_CRH     (*(volatile uint32_t *)0x40011004U)
#define GPIOC_BSRR    (*(volatile uint32_t *)0x40011010U)

#define SYST_CSR      (*(volatile uint32_t *)0xE000E010U)
#define SYST_RVR      (*(volatile uint32_t *)0xE000E014U)
#define SYST_CVR      (*(volatile uint32_t *)0xE000E018U)

#define RCC_IOPAEN    (1U << 2)
#define RCC_IOPCEN    (1U << 4)

#define BUTTON_PIN    0U     /* PA0 */
#define LED_PIN       13U    /* PC13 - LED onboard Blue Pill */

#define BUTTON_MASK   (1U << BUTTON_PIN)
#define LED_MASK      (1U << LED_PIN)

/* Blue Pill onboard LED at PC13 is active-low. */
static void LED_Set(bool on)
{
    if (on)
    {
        /* Reset PC13 -> output LOW -> LED ON. */
        GPIOC_BSRR = (LED_MASK << 16U);
    }
    else
    {
        /* Set PC13 -> output HIGH -> LED OFF. */
        GPIOC_BSRR = LED_MASK;
    }
}

static bool Button_IsPressed(void)
{
    /* PA0 uses internal pull-up: pressed = connected to GND = logic 0. */
    return ((GPIOA_IDR & BUTTON_MASK) == 0U);
}

static void SysTick_Init_1ms(void)
{
    /* Reset clock is HSI = 8 MHz. Reload 8000 clocks gives 1 ms. */
    SYST_RVR = 8000U - 1U;
    SYST_CVR = 0U;
    SYST_CSR = (1U << 2) | (1U << 0);  /* CLKSOURCE=CPU, ENABLE=1 */
}

static void Delay_ms(uint32_t ms)
{
    while (ms-- > 0U)
    {
        /* COUNTFLAG becomes 1 each time SysTick reaches zero. */
        while ((SYST_CSR & (1U << 16)) == 0U)
        {
            /* wait */
        }
    }
}

static void GPIO_Init(void)
{
    /* Enable GPIOA and GPIOC clocks. */
    RCC_APB2ENR |= RCC_IOPAEN | RCC_IOPCEN;

    /* PA0: input with pull-up/pull-down.
       MODE0 = 00, CNF0 = 10 -> nibble = 0b1000 = 0x8. */
    GPIOA_CRL &= ~(0xFU << (BUTTON_PIN * 4U));
    GPIOA_CRL |=  (0x8U << (BUTTON_PIN * 4U));

    /* Select pull-up for PA0 by setting ODR0 = 1. */
    GPIOA_ODR |= BUTTON_MASK;

    /* PC13: general-purpose output push-pull, 2 MHz.
       PC13 is in CRH. Pin index inside CRH = 13 - 8 = 5.
       MODE13 = 10, CNF13 = 00 -> nibble = 0x2. */
    const uint32_t pc13_shift = (LED_PIN - 8U) * 4U;
    GPIOC_CRH &= ~(0xFU << pc13_shift);
    GPIOC_CRH |=  (0x2U << pc13_shift);
}

int main(void)
{
    bool led_state = false;

    GPIO_Init();
    SysTick_Init_1ms();

    /* Initial state: LED OFF. */
    LED_Set(led_state);

    while (1)
    {
        /* Detect a button press. */
        if (Button_IsPressed())
        {
            /* Debounce the press. */
            Delay_ms(20U);

            if (Button_IsPressed())
            {
                /* Wait until the user releases the button.
                   LED remains unchanged while the button is held. */
                while (Button_IsPressed())
                {
                    /* wait for release */
                }

                /* Debounce the release. */
                Delay_ms(20U);

                /* Confirm the button is really released, then toggle LED. */
                if (!Button_IsPressed())
                {
                    led_state = !led_state;
                    LED_Set(led_state);
                }
            }
        }
    }
}
