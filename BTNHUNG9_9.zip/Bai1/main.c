#include <stdint.h>

/* STM32F103C8T6 - Blue Pill
 * LED on PC13 is active-low.
 * Default clock after reset: HSI = 8 MHz.
 */

#define RCC_BASE        0x40021000UL
#define GPIOC_BASE      0x40011000UL
#define SYSTICK_BASE    0xE000E010UL

#define RCC_APB2ENR     (*(volatile uint32_t *)(RCC_BASE + 0x18UL))
#define GPIOC_CRH       (*(volatile uint32_t *)(GPIOC_BASE + 0x04UL))
#define GPIOC_BSRR      (*(volatile uint32_t *)(GPIOC_BASE + 0x10UL))
#define GPIOC_BRR       (*(volatile uint32_t *)(GPIOC_BASE + 0x14UL))

#define SYST_CSR        (*(volatile uint32_t *)(SYSTICK_BASE + 0x00UL))
#define SYST_RVR        (*(volatile uint32_t *)(SYSTICK_BASE + 0x04UL))
#define SYST_CVR        (*(volatile uint32_t *)(SYSTICK_BASE + 0x08UL))

#define LED_PIN         13U
#define LED_DELAY_MS    1000U   /* Change this value to change blink speed */

static void systick_init_1ms(void)
{
    /* 8 MHz / 1000 = 8000 clocks per 1 ms */
    SYST_RVR = 8000U - 1U;
    SYST_CVR = 0U;
    /* ENABLE=1, TICKINT=0, CLKSOURCE=1 (processor clock) */
    SYST_CSR = (1U << 2) | (1U << 0);
}

static void delay_ms(uint32_t ms)
{
    while (ms--)
    {
        /* COUNTFLAG (bit 16) becomes 1 when SysTick counts to zero */
        while ((SYST_CSR & (1U << 16)) == 0U)
        {
            /* wait */
        }
    }
}

int main(void)
{
    /* Enable GPIOC clock: RCC_APB2ENR.IOPCEN = 1 */
    RCC_APB2ENR |= (1U << 4);

    /* PC13 is controlled by GPIOC_CRH bits 23:20.
     * CNF13[1:0] = 00: General-purpose push-pull
     * MODE13[1:0] = 10: Output mode, max speed 2 MHz
     */
    GPIOC_CRH &= ~(0xFU << 20);
    GPIOC_CRH |=  (0x2U << 20);

    /* LED off initially (PC13 = 1 on Blue Pill) */
    GPIOC_BSRR = (1U << LED_PIN);

    systick_init_1ms();

    while (1)
    {
        /* LED ON: PC13 = 0 */
        GPIOC_BRR = (1U << LED_PIN);
        delay_ms(LED_DELAY_MS);

        /* LED OFF: PC13 = 1 */
        GPIOC_BSRR = (1U << LED_PIN);
        delay_ms(LED_DELAY_MS);
    }
}
