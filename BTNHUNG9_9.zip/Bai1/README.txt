STM32F103C8T6 PC13 LED BLINK PROJECT

Function:
- Configure PC13 as General Purpose Output Push-Pull, 2 MHz.
- Blink the Blue Pill onboard LED.
- LED ON for 1000 ms, OFF for 1000 ms.
- Change LED_DELAY_MS in main.c to change the blink interval.

Main source files:
- main.c
- startup_stm32f103.s
- STM32F103C8Tx_FLASH.ld

Generated build files:
- main.o
- startup_stm32f103.o
- led.elf
- led.bin
- led.hex
- led.map
- led.lst

Windows CMD:
Run build_windows_cmd.bat after installing GNU Arm Embedded Toolchain and adding arm-none-eabi-* to PATH.

Linux:
Run ./build_linux.sh after installing gcc-arm-none-eabi.

Flashing with ST-Link:
st-flash write led.bin 0x08000000

Note:
The included generated artifacts were built for ARM Cortex-M3 and STM32F103C8T6 memory layout.
