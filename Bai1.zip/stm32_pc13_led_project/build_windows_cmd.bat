@echo off
REM Build on Windows CMD using GNU Arm Embedded Toolchain
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -Os -ffreestanding -fno-builtin -c main.c -o main.o
if errorlevel 1 exit /b 1
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -c startup_stm32f103.s -o startup_stm32f103.o
if errorlevel 1 exit /b 1
arm-none-eabi-gcc -mcpu=cortex-m3 -mthumb -nostdlib main.o startup_stm32f103.o -T STM32F103C8Tx_FLASH.ld -Wl,-Map=led.map -o led.elf
if errorlevel 1 exit /b 1
arm-none-eabi-objcopy -O binary led.elf led.bin
arm-none-eabi-objcopy -O ihex led.elf led.hex
arm-none-eabi-objdump -d -S led.elf > led.lst
arm-none-eabi-size led.elf

echo.
echo Build complete.
dir
